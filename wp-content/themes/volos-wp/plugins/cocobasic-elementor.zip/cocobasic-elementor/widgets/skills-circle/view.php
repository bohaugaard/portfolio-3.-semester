<div class="skill-circle-holder">
    <?php echo $this->content($settings['items']);?> 
</div>

